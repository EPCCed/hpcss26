import numpy as np
import random
import time

# Simple RuLU activation where it is expecting a python list
def simple_ReLU(data):
    output_data = []
    
    if not isinstance(data, list):
        print("Wrong data type passed to simple_ReLU")
        return output_data

    for item in data:
        if(item > 0.0):
            output_data.append(item)
        else:
            output_data.append(0.0)

    return output_data

# Simple ReLU activiation where it is expecting a numpy array
def numpy_simple_ReLU(data,size):

    output_data = np.empty(size)
    
    if not isinstance(data, np.ndarray):
        print("Wrong data type passed to numpy_simple_ReLU")
        return output_data

    for index,item in enumerate(data):
        if(item > 0.0):
            output_data[index] = item
        else:
            output_data[index] = 0.0

    return output_data

# Numpy where ReLU activiation where it is expecting a numpy array
def numpy_where_ReLU(data,size):

    output_data = np.empty(size)
    
    if not isinstance(data, np.ndarray):
        print("Wrong data type passed to numpy_where_ReLU")
        return output_data

    output_data =  np.where(data > 0, data, 0)
    return output_data

# Numpy where Leaky_ReLU activiation where it is expecting a numpy array
def numpy_where_leaky_ReLU(data,size):

    output_data = np.empty(size)
    
    if not isinstance(data, np.ndarray):
        print("Wrong data type passed to numpy_where_leaky_ReLU")
        return output_data

    output_data =  np.where(data > 0, data, data*0.01)
    return output_data


def numpy_sigmoid(data,size):

    output_data = np.empty(size)

    if not isinstance(data, np.ndarray):
        print("Wrong data type passed to numpy_sigmoid")
        return output_data
    
    # Implement a sigmoid activation function
    # Sigmoid is defined as 1 / (1 + e^-x) where x is the data you're using
    # You can use the numpy exp function to implement the e^ part
#    output_data = 
    return output_data

def numpy_tanh(data,size):

    output_data = np.empty(size)

    if not isinstance(data, np.ndarray):
        print("Wrong data type passed to numpy_tanh")
        return output_data
    
    # Implement a tanh activation function
    # Tanh is defined as (1 - e^-2x) / (1 + e^-2x) where x is the data you're using
    # You can use the numpy exp function to implement the e^ part
#    output_data = 
    return output_data


def numpy_softmax(data,size):

    import scipy as sp
    output_data = np.empty(size)

    if not isinstance(data, np.ndarray):
        print("Wrong data type passed to numpy_softmax")
        return output_data
    
    # Implement a softmax activation function
    # Softmax is defined as e^x_i/sum(e^x)
    # You can use the numpy exp function to implement the e^ part
#    output_data = 
    return output_data


def main():
    list_data = []
    size = 10000000
    repeats = 10

    for i in range(size):
        list_data.append(random.uniform(-1.0,1.0))

    numpy_data =  np.random.uniform(-1.0,1.0,size)
        
    start = time.time()
    for i in range(10):
        output_data = simple_ReLU(list_data)
    end = time.time()
    print("Runtime for simple ReLU is " + str((end-start)/repeats))
    
    start = time.time()
    for i in range(10):
        output_data = numpy_simple_ReLU(numpy_data,size)
    end = time.time()
    print("Runtime for simple numpy ReLU is " + str((end-start)/repeats))
    
    start = time.time()
    for i in range(10):
        output_data = numpy_where_ReLU(numpy_data,size)
    end = time.time()
    print("Runtime for numpy where-based ReLU is " + str((end-start)/repeats))

    start = time.time()
    for i in range(10):
        output_data = numpy_where_leaky_ReLU(numpy_data,size)
    end = time.time()
    print("Runtime for numpy where-based Leaky ReLU is " + str((end-start)/repeats))
    
    start = time.time()
# Uncomment when you have implemented the function
#    for i in range(10):
#        output_data = numpy_sigmoid(numpy_data,size)
    end = time.time()
    print("Runtime for numpy Sigmoid is " + str((end-start)/repeats))

    start = time.time()
# Uncomment when you have implemented the function    
#    for i in range(10):
#        output_data = numpy_tanh(numpy_data,size)
    end = time.time()
    print("Runtime for numpy Tanh is " + str((end-start)/repeats))

    start = time.time()
# Uncomment when you have implemented the function
#    for i in range(10):
#        output_data = numpy_softmax(numpy_data,size)
    end = time.time()
    print("Runtime for numpy Softmax is " + str((end-start)/repeats))
    
    
if __name__ == "__main__":
    main()
