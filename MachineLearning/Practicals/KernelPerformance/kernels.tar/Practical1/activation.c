#include<stdio.h>
#include<stdlib.h>
#include<sys/time.h>
#include<float.h>
#include<math.h>

static double mysecond(){
  struct timeval tp;
  struct timezone tzp;
  int i;

  i = gettimeofday(&tp,&tzp);
  return ( (double) tp.tv_sec + (double) tp.tv_usec * 1.e-6 );
}

void ReLU(double *restrict data, double *restrict output, int size){

  int i;
  
  for(i=0; i<size; i++){
    if(data[i] > 0.0){
      output[i] = data[i];
    }else{
      output[i] = 0.0;
    }
  }

  return;
  
}

void ReLU_Optimised(double *restrict data, double *restrict output, int size){

  int i, temp;

  for(i=0; i<size; i++){
    temp = (data[i] > 0.0);
    output[i] = temp * data[i];
  }

  return;
  
}

void Leaky_ReLU(double *restrict data, double *restrict output, int size){

  int i;
  
  for(i=0; i<size; i++){
    if(data[i] > 0.0){
      output[i] = data[i];
    }else{
      output[i] = 0.01*data[i];
    }
  }

  return;
  
}


void Leaky_ReLU_Optimised(double *restrict data, double *restrict output, int size){

  int i, temp1, temp2;

  for(i=0; i<size; i++){
    temp1 = (data[i] <= 0.0);
    temp2 = (data[i] > 0.0);
    output[i] = (temp1 * 0.01 * data[i]) + (temp2 * data[i]);
  }

  return;
  
}


void Sigmoid(double *restrict data, double *restrict output, int size){

  int i;

  for(i=0; i<size; i++){
    output[i] = 1/(1+exp(data[i]));
  }

  return;
  
}

void Tanh(double *restrict data, double *restrict output, int size){

  int i;

  for(i=0; i<size; i++){
    output[i] = (1-exp(-2*data[i]))/(1+exp(-2*data[i]));
  }

  return;
  
}

void Softmax(double *restrict data, double *restrict output, int size){

  int i;
  double temp;

  temp = 0.0;
  for(i=0; i<size; i++){
    temp += exp(data[i]);
  }

  for(i=0; i<size; i++){
    output[i] = exp(data[i])/temp;
  }

  return;
  
}




int main(int argc, char **argv){

  int i;
  int size = 10000000;
  int repeats = 10;
  double data[size], output[size];
  double start, end;
  
  for(i=0; i<size; i++){
    data[i] = ((rand()*1.0)/RAND_MAX * 2.0) - 1.0; 
  }
  
  start = mysecond();
  for(i=0; i<repeats; i++){
    ReLU(data, output, size);
  }
  end = mysecond();
  printf("ReLU Runtime for %d operations is %lf (single operation %lf)\n", repeats, (end-start), (end-start)/repeats);
  
  start = mysecond();
  for(i=0; i<repeats; i++){
    ReLU_Optimised(data, output, size);
  }
  end = mysecond();
  printf("Optimised ReLU Runtime for %d operations is %lf (single operation %lf)\n", repeats, (end-start), (end-start)/repeats);

  start = mysecond();
  for(i=0; i<repeats; i++){
    Leaky_ReLU(data, output, size);
  }
  end = mysecond();
  printf("Leaky ReLU Runtime for %d operations is %lf (single operation %lf)\n", repeats, (end-start), (end-start)/repeats);
  
  start = mysecond();
  for(i=0; i<repeats; i++){
    Leaky_ReLU_Optimised(data, output, size);
  }
  end = mysecond();
  printf("Optimised Leaky ReLU Runtime for %d operations is %lf (single operation %lf)\n", repeats, (end-start), (end-start)/repeats);

  start = mysecond();
  for(i=0; i<repeats; i++){
    Sigmoid(data, output, size);
  }
  end = mysecond();
  printf("Sigmoid Runtime for %d operations is %lf (single operation %lf)\n", repeats, (end-start), (end-start)/repeats);

  start = mysecond();
  for(i=0; i<repeats; i++){
    Tanh(data, output, size);
  }
  end = mysecond();
  printf("Tanh Runtime for %d operations is %lf (single operation %lf)\n", repeats, (end-start), (end-start)/repeats);

  start = mysecond();
  for(i=0; i<repeats; i++){
    Softmax(data, output, size);
  }
  end = mysecond();
  printf("Softmax Runtime for %d operations is %lf (single operation %lf)\n", repeats, (end-start), (end-start)/repeats);

  
  
  return 0;
  
}
