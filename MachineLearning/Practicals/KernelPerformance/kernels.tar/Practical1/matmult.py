import numpy as np
import time
import scipy as sp

repeats = 100
array_size = 128

def numpy_matmult(matrix1, matrix2):

    # Perform matrix-matrix multiplication
    result = np.dot(matrix1, matrix2)
    return result
    
def scipy_matmult(matrix1, matrix2):
    
    result = sp.linalg.blas.sgemm(1.0, matrix1, matrix2)
    return result
    
print("Using a matrix size of " + str(array_size) + " x " + str(array_size))
print("Repeating each benchmark " + str(repeats) + " times")

matrix1_np = np.random.rand(array_size, array_size)
matrix2_np = np.random.rand(array_size, array_size)

start = time.time()
for i in range(repeats):
    numpy_matmult(matrix1_np, matrix2_np)
end = time.time()
print("NumPy Mat Mult Time: " + str((end - start)/repeats))

matrix1_np = np.random.rand(array_size, array_size).astype(np.float32)
matrix2_np = np.random.rand(array_size, array_size).astype(np.float32)

start = time.time()
for i in range(repeats):
    numpy_matmult(matrix1_np, matrix2_np)
end = time.time()
print("NumPy Reduced Precision (32-bit float) Mat Mult Time: " + str((end - start)/repeats))

matrix1_np = np.random.rand(array_size, array_size).astype(np.float16)
matrix2_np = np.random.rand(array_size, array_size).astype(np.float16)

start = time.time()
for i in range(repeats):
    numpy_matmult(matrix1_np, matrix2_np)
end = time.time()
print("NumPy Reduced Precision (16-bit float) Mat Mult Time: " + str((end - start)/repeats))

matrix1_np = np.random.rand(array_size, array_size).astype(np.float32)
matrix2_np = np.random.rand(array_size, array_size).astype(np.float32)

start = time.time()
for i in range(repeats):
    scipy_matmult(matrix1_np, matrix2_np)
end = time.time()
print("SciPy Reduced Precision (32-bit float) Mat Mult Time: " + str((end - start)/repeats))

matrix1_np = np.random.rand(array_size, array_size).astype(np.float32)
matrix2_np = np.random.rand(array_size, array_size).astype(np.float32)
matrix1_np = np.ascontiguousarray(matrix1_np)
matrix2_np = np.ascontiguousarray(matrix2_np)

print(matrix1_np.flags)
print(matrix2_np.flags)

start = time.time()
for i in range(repeats):
    numpy_matmult(matrix1_np, matrix2_np)
end = time.time()
print("NumPy Reduced Precision (32-bit float) with C Formatting Mat Mult Time: " + str((end - start)/repeats))

matrix1_np = np.random.rand(array_size, array_size).astype(np.float32)
matrix2_np = np.random.rand(array_size, array_size).astype(np.float32)
matrix1_np = np.asfortranarray(matrix1_np)
matrix2_np = np.asfortranarray(matrix2_np)

print(matrix1_np.flags)
print(matrix2_np.flags)

start = time.time()
for i in range(repeats):
    numpy_matmult(matrix1_np, matrix2_np)
end = time.time()
print("NumPy Reduced Precision (32-bit float) with Fortran Formatting Mat Mult Time: " + str((end - start)/repeats))

start = time.time()
for i in range(repeats):
    scipy_matmult(matrix1_np, matrix2_np)
end = time.time()
print("SciPy Reduced Precision (32-bit float) with Fortran Formatting Mat Mult Time: " + str((end - start)/repeats))


