import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torchvision import transforms
import os
import sys
import random
import time

def display_data(data,groundtruth):
    matplotlib.use("tkagg")
    fig = plt.figure()
    fig.suptitle("First 16 images with their actual values")
    for i in range(16):
        plt.subplot(4,4,i+1)
        plt.tight_layout()
        plt.imshow(data[i], cmap='gray', interpolation='none')
        plt.title("Ground Truth: {}".format(groundtruth[i]))
        plt.xticks([])
        plt.yticks([])
    plt.show()

def display_single_data(data,prediction,groundtruth):
    matplotlib.use("tkagg")
    fig = plt.figure()
    fig.suptitle("Image with predicted and actual values")
    plt.tight_layout()
    plt.imshow(data, cmap='gray', interpolation='none')
    plt.title("Prediction: {}".format(prediction) + " Ground Truth: {}".format(groundtruth))
    plt.xticks([])
    plt.yticks([])
    plt.show()
    
def get_data(maximum=sys.maxsize):
    if(maximum == -1):
        maximum = sys.maxsize
    x_train = []
    counter = 0
    for file in sorted(os.listdir('/home/eidf018/eidf018/shared/mlas/mnist/x_train')):
        if(counter > maximum):
            break
        counter = counter + 1
        data = np.loadtxt('/home/eidf018/eidf018/shared/mlas/mnist/x_train/'+file,dtype=np.uint8)
        x_train.append(data.reshape(28,28))
    x_test = []
    counter = 0
    for file in sorted(os.listdir('/home/eidf018/eidf018/shared/mlas/mnist/x_test')):
        if(counter > maximum):
            break
        counter = counter + 1
        data = np.loadtxt('/home/eidf018/eidf018/shared/mlas/mnist/x_test/'+file,dtype=np.uint8)
        x_test.append(data.reshape(28,28))
    y_train = []
    counter = 0
    for file in sorted(os.listdir('/home/eidf018/eidf018/shared/mlas/mnist/y_train')):
        if(counter > maximum):
            break
        counter = counter + 1
        data = np.loadtxt('/home/eidf018/eidf018/shared/mlas/mnist/y_train/'+file,dtype=np.uint8)
        y_train.append(data)
    y_test = []
    counter = 0
    for file in sorted(os.listdir('/home/eidf018/eidf018/shared/mlas/mnist/y_test')):
        if(counter > maximum):
            break
        counter = counter + 1
        data = np.loadtxt('/home/eidf018/eidf018/shared/mlas/mnist/y_test/'+file,dtype=np.uint8)
        y_test.append(data)    

    return x_train,y_train,x_test,y_test


# This class will hold the network definition
# You will need to add code to get it to work
class Network(nn.Module):

    def __init__(self):
        super(Network, self).__init__()

        # We have defined some parameters for you. This can be experimented with.
        input_size = 784
        hidden_sizes = [128, 64]
        output_size = 10
        drop_out = 0.1

        # Currently we only have an input layer and an output layer. To make this
        # network function properly you will need to add some more layers/activation
        # functions.
        self.linear = nn.Sequential(nn.Linear(input_size, hidden_sizes[0]),
                                    nn.Linear(hidden_sizes[0],output_size))
                                    
    # You can add some functionality to initialise weights if required
    def init_weights(self):
        # This is currently empty
        a = 1
        
    # This the function that is called for the forward propagation pass. Currently it
    # calls the linear object, but you can modify this if required.
    def forward(self, x):
        
        x = self.linear(x)
        return x

# This is the main program that is run
if __name__ == '__main__':

    # Initialise some runtime parameters
    number_of_images_to_use = -1
    display_images = False

    # Setup the command line parameters and get their values if they are passed
    if(len(sys.argv)> 1):
        number_of_images_to_use = int(sys.argv[1])

    if(len(sys.argv) > 2):
        display_images = bool(sys.argv[2])

    if(number_of_images_to_use == -1):
        print("Using all the training and test data set")
    else:
        print("Using " + str(number_of_images_to_use) + " training and test images")

    if(display_images):
        print("Displaying a sample of the images")
    else:
        print("Not displaying images")

    start = time.time()
    # Initial data loading
    x_train,y_train,x_test,y_test = get_data(number_of_images_to_use)
    end = time.time()
    print("It took {} second to read in the datasets".format(end-start))
    
    # Display a picture of the images
    if(display_images):
        display_data(x_train,y_train)

    # Convert the data into a form that can be easily processed by PyTorch and converted into Tensors
    x_train = np.stack(x_train)
    y_train = np.asarray(y_train)
    x_test = np.stack(x_test)
    y_test = np.asarray(y_test)
    x_train = np.rollaxis(x_train,0,3)
    x_test = np.rollaxis(x_test,0,3)

    # Use PyTorch functionality to transform the images into normalised input in the range [0 1]
    transform = transforms.Compose([transforms.ToTensor(),transforms.Normalize((0.1307,), (0.3081,))])
    x_train = transform(x_train)
    x_test = transform(x_test)

    # Convert the labels for the dataset into Tensors as well.
    y_train = torch.from_numpy(y_train)
    y_test = torch.from_numpy(y_test)

    # Create the model
    model = Network()

    # At the moment the model is only on the CPU because PyTorch defaults to the CPU
    # To run on the GPU you will need to transfer the model to the GPU here
    # Add in code to do that once you have developed the model.
    # It might be sensible to define a device variable here you can use elsewhere in the code
    #device = ("cuda" if torch.cuda.is_available() else "cpu")
    
    # Next you need to create and configure the optimiser here and loss function

    # We have defined the number of iterations to run, but you can change this
    epochs = 10

    start = time.time()

    # Initialise the model for training
    model.train()
    
    for epoch in range(epochs):
        
        train_loss = 0

        # For each image in the data set do the following
        # As we are not currently using batches here, this is Gradient Descent, rather than
        # SGD.
        # As an optional exercise you could batch up the input files are run SGD here instead.
        for item in range(len(x_train)):

            image = x_train[item]
            label = y_train[item]

            # Convert the image from 28x28 to 768 so it can be fed into the network
            image = image.flatten()

            # You will need to add in the optimiser and model calls

            # You will need to add in the backwards propagation step and loss calculation


        # You shoud print out the training lost here
        print("Epoch: {}/{}  ".format(epoch+1, epochs),
              "Training loss: {:.4f}  ".format(train_loss/len(x_train)))
        
    end = time.time()

    print("Time to train was {} seconds".format(end-start))
            
    # Prepare for inference on the test set rather than training
    model.eval() 
    test_loss = 0
    accuracy = 0
    total_correct = 0
    
    # Turn off the gradient updates when performing validation
    with torch.no_grad():
        for item in range(len(x_test)):
            
            image = x_test[item]
            label = y_test[item]

            image = image.flatten()

            # You will need to add in the inference/forward step here

            # You will need to add a calculation of the prediction vs the actual label for the data
            # and use that to calculate overall accuracy
