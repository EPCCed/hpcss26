import numpy as np
import time
import scipy as sp

def matmult(matrix1, matrix2):

    # You need to add in a matrix multiplication function here
    return

def accumulate(vector):

    # We have provided an accumulate function for you
    return np.sum(vector)

def activation(vector):

    # You need to add in an activation function here
    return 
    
def main():

    repeats = 1000
    array_size = 128

    
    print("Using a matrix size of " + str(array_size) + " x " + str(array_size))
    print("Repeating each benchmark " + str(repeats) + " times")
    
    matrix1_np = np.random.uniform(-1.0,1.0,(array_size,array_size))
    matrix2_np = np.random.uniform(-1.0,1.0,(array_size,array_size))
    weight_edge = np.empty((array_size, array_size))
    results = np.empty(array_size)

    matmulttime = 0.0
    accumulatetime = 0.0
    activationtime = 0.0
    
    for i in range(repeats):
        
        start = time.time()
        weight_edge = matmult(matrix1_np, matrix2_np)
        end = time.time()
        matmulttime = matmulttime + (end-start)
        
        start = time.time()
        for j in range(array_size):
            results[j] = accumulate(weight_edge[j, :])
        end = time.time()
        accumulatetime = accumulatetime + (end-start)
        
        start = time.time()
        results = activation(results)
        end = time.time()
        activationtime = activationtime + (end-start)
        
    print("Mat Mult Time: " + str(matmulttime/repeats))
    print("Accumulate Time: " + str(accumulatetime/repeats))
    print("Activation Time: " + str(activationtime/repeats))    
        
    

if __name__ == "__main__":
    main()

